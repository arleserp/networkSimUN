#!/bin/sh
i=1
while [ $i -le 30 ]; do
echo $i # i=$(($i+1))
java  -classpath NetworkSimulator.jar unalcol.agents.NetworkSim.util.BoxPlotRoundNumberSort . topology 350 600
done