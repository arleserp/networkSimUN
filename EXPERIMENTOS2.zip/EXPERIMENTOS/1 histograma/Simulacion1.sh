#!/bin/sh
i=1
while [ $i -le 30 ]; do
echo $i # i=$(($i+1))
java  -classpath ../../dist/NetworkSimulator.jar unalcol.agents.NetworkSim.util.SuccessRatesReport . 500 450
done